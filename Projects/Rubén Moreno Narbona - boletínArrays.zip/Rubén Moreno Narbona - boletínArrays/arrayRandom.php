<?php

$arrayRandom = array("countries" => array(1, 3, 5),
                            "age" => 40);
?>
