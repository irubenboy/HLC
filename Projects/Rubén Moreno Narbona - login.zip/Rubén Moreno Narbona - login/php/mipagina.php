<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mi Página</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .main{
            top:15%;
            left: 25%;
        }
    </style>
</head>
<body>
    <div class="main">
        <h1 id = "title">Mi página web</h1>
        <div class="info">
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Porro libero architecto a excepturi modi est nemo iusto voluptates, praesentium reiciendis saepe ipsam ex quas inventore corrupti voluptatum, accusantium dolore dolor?</p>
            <img src="https://www.movilzona.es/app/uploads/2018/10/app-foto-movimiento.jpg" alt="imagen">
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Soluta vitae eveniet repellat consequuntur aliquam, debitis harum ipsa? Possimus repellendus enim sed laudantium assumenda asperiores reprehenderit, consectetur quasi! Magnam, iste sit?</p>
        </div>
    </div>
</body>
</html>