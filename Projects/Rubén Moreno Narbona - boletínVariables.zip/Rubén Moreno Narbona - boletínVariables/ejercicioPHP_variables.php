<?php

/*************************************************************************************************************************
*                                       BOLETIN EJERCICIOS VARIABLES
***************************************************************************************************************************/

//Crear un fichero llamado index.php que contenga una estrcutura html. El html tiene que estar
// formado por un título (Boletín Variables)y una lista en la que cada elemento de la lista será 
//el enunciado de cada uno de los ejercicios a realizar.
// Al final de cada enunciado habrá un enlace que me llevará al ejercicio en cuestión.
//El archivo html tendrá que tener estilo (libre elección).

// 1.Escribe un programa que muestre tu nombre por pantalla, nombre del ciclo formativo que estás 
// realizando y curso.

// 2.Modifica el programa anterior para que muestre tu dirección, nombre de las asignaturas 
// del ciclo.El texto debe aparecer en una línea diferente.

// 3.Escribe un programa que muestre tu horario de clase mediante una tabla, el recreo debe de aparecer.
// Dale formato y estilos a la tabla.

// 4.Crea la variable $nombre y asígnale tu nombre completo, crea la variable ciclo y asiga el 
// nombre del ciclo. Muestralo por pantalla como el ejercicio 1.

// 5.Crea un conversor de moneda, de dólares a libras Australianos. Haz uso de variables.

// 6.Crea un conversor de moneda, de libras a dólares Australianos. Haz uso de variables.

//7.Pinta una pirámide invertida y hueca con asteriscos.

?>
