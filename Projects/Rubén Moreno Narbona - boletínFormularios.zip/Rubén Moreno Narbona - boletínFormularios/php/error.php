<?php
define("ERRNO_1", "Error no has indicado el nombre");
define("ERRNO_2", "Error no has indicado una edad númerica o está vacía")
?>