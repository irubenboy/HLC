<?php
    $cad = "Uno, dos, tres, cuatro";
    $array = explode(",", $cad);

    echo "<pre>";
    print_r($array);
    echo "</pre>";
?>