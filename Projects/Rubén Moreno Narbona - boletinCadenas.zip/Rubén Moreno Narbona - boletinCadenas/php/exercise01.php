<?php
    $cadena = "En un lugar de la mancha de cuyo nombre no quiero
    acordarme";

    echo "Mayúsculas: " . strtoupper($cadena), "<br>", "Minúsculas: " . strtolower($cadena), "<br>", "Primera letra mayúsculas: " . ucfirst($cadena), "<br>", "Primera letra minúsculas: " . lcfirst($cadena);
?>