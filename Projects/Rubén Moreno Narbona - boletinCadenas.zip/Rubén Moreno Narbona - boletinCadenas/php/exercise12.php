<?php
    $caracterDado = 'a';
    $caracterEsperado = chr(ord($caracterDado) + 1);

    printf("Carácter dado: %s <br> Carácter Esperado: %s<br>", $caracterDado,
    $caracterEsperado);
?>