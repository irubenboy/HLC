<?php
    $cadena = "En un lugar de la mancha cuyo nombre no quiero acordarme";
    $replaced = "lugar";
    $replace = "planeta";

    echo str_replace($replaced, $replace, $cadena);
?>