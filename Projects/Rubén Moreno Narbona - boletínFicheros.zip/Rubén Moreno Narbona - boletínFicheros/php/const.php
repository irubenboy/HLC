<?php
/* ERRORES */
$errors_const = [
    "ERRNO_1" => "Titutlo no puede ser vacío",
    "ERRNO_2" => "Problemas al abrir el fichero",
    "ERRNO_3" => "No se ha podido insertar el libro",
    "ERRNO_4" => "Título y tipo son obligatorios",
    "ERRNO_5" => "Fichero vacío"
];
/* ACIERTOS */
$rights_const = [
    "RIGNO_1" => "Libro Insertado Correctamente"
]
?>