<?php
/* MENSAJE DE ACCIÓN CORRECTA */
define("RIGNO_1", " ha sido subido con éxito");
define("RIGNO_2", " ha sido escrito con éxito");
/* MENSAJE DE ACCIÓN INCORRECTA */
define("ERRNO_1", " no se ha subido");
define("ERRNO_2", " Extensión no permitida");
define("ERRNO_3", " sobrepasa el tamaño máximo: 512KB");
define("ERRNO_4", " no se ha subido con éxtio");
define("ERRNO_5", " no se ha podido abrir");
define("ERRNO_6", " no se ha podido escribir");
?>